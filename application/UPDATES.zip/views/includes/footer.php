<div class="row">
  <div class="col-lg-12">
    <div class="footer">
      <p>2024 © DOLE Oriental Mindoro</p>
    </div>
  </div>
</div>